import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { MongoClient } from "mongodb";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  let mongoClient: MongoClient | null = null;
  
  const getMongoClient = async () => {
    if (mongoClient) return mongoClient;
    const uri = process.env.MONGODB_URI;
    if (!uri) {
      throw new Error("MONGODB_URI environment variable is not set. Please set it in the Secrets panel.");
    }
    mongoClient = new MongoClient(uri);
    await mongoClient.connect();
    return mongoClient;
  };

  app.get(api.collections.list.path, async (req, res) => {
    try {
      const client = await getMongoClient();
      const db = client.db();
      const collections = await db.listCollections().toArray();
      const collectionNames = collections.map(c => c.name);
      res.json(collectionNames);
    } catch (err: any) {
      console.error("MongoDB Error:", err);
      res.status(500).json({ message: "Failed to fetch collections", details: err.message });
    }
  });

  app.get(api.history.list.path, async (req, res) => {
    try {
      const history = await storage.getQueryHistory();
      res.json(history);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  app.post(api.query.execute.path, async (req, res) => {
    try {
      const input = api.query.execute.input.parse(req.body);
      
      const client = await getMongoClient();
      const db = client.db();
      const collection = db.collection(input.collection);
      
      // Get a sample document to help the LLM understand the schema
      const sampleDoc = await collection.findOne({});
      const schemaHint = sampleDoc ? Object.keys(sampleDoc) : ["No sample data available"];
      
      const prompt = `You are a MongoDB expert. Given the following natural language query, write a MongoDB aggregation pipeline or find query to retrieve the data.
Collection Name: ${input.collection}
Sample Document Keys: ${JSON.stringify(schemaHint)}

Query: "${input.question}"

Return ONLY valid JSON representing the query object to pass to the MongoDB driver.
For example, for a find query: { "find": { "age": { "$gt": 20 } }, "limit": 10, "sort": {"age": -1} }
For an aggregation: { "aggregate": [ { "$match": { "status": "A" } }, { "$group": { "_id": "$cust_id", "total": { "$sum": "$amount" } } } ] }

Do not include markdown blocks, just the JSON string. Ensure it is valid JSON.`;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" }
      });
      
      const mongoQueryStr = response.choices[0]?.message?.content || "{}";
      const mongoQuery = JSON.parse(mongoQueryStr);
      
      let results: any[] = [];
      if (mongoQuery.aggregate) {
        results = await collection.aggregate(mongoQuery.aggregate).toArray();
      } else if (mongoQuery.find) {
        let cursor = collection.find(mongoQuery.find);
        if (mongoQuery.sort) cursor = cursor.sort(mongoQuery.sort);
        if (mongoQuery.limit) cursor = cursor.limit(mongoQuery.limit);
        results = await cursor.toArray();
      } else {
        // Fallback or assume simple find
        results = await collection.find(mongoQuery).toArray();
      }
      
      // Save history
      await storage.saveQueryHistory({
        question: input.question,
        collection: input.collection,
        mongoQuery: JSON.stringify(mongoQuery),
        resultCount: results.length,
      });

      res.status(200).json({
        question: input.question,
        mongoQuery: mongoQuery,
        results: results,
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      console.error("Query Error:", err);
      res.status(500).json({ message: "Failed to execute query", details: err.message });
    }
  });

  return httpServer;
}
