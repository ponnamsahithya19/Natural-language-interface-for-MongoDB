import { db } from "./db";
import { queryHistory } from "@shared/schema";

async function seed() {
  const existing = await db.select().from(queryHistory);
  if (existing.length === 0) {
    console.log("Seeding query history...");
    await db.insert(queryHistory).values([
      {
        question: "Show all active users",
        collection: "users",
        mongoQuery: JSON.stringify({ find: { status: "active" } }),
        resultCount: 5,
      },
      {
        question: "Find orders above 500 dollars",
        collection: "orders",
        mongoQuery: JSON.stringify({ find: { amount: { $gt: 500 } } }),
        resultCount: 12,
      }
    ]);
    console.log("Database seeded successfully");
  } else {
    console.log("Database already seeded");
  }
}

seed().catch(console.error).then(() => process.exit(0));
