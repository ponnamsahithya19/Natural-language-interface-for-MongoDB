import { db } from "./db";
import { queryHistory, type InsertQueryHistory, type QueryHistory } from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  getQueryHistory(): Promise<QueryHistory[]>;
  saveQueryHistory(history: InsertQueryHistory): Promise<QueryHistory>;
}

export class DatabaseStorage implements IStorage {
  async getQueryHistory(): Promise<QueryHistory[]> {
    return await db.select().from(queryHistory).orderBy(desc(queryHistory.createdAt));
  }

  async saveQueryHistory(history: InsertQueryHistory): Promise<QueryHistory> {
    const [saved] = await db.insert(queryHistory).values(history).returning();
    return saved;
  }
}

export const storage = new DatabaseStorage();
