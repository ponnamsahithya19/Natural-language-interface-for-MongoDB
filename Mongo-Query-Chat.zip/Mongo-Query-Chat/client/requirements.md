## Packages
framer-motion | Smooth animations for result transitions
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging tailwind classes

## Notes
- API endpoints:
  - GET /api/collections (list collections)
  - POST /api/query (execute NL query)
  - GET /api/history (list query history)
- Components needed:
  - QueryInput: Textarea for natural language
  - ResultsTable: Dynamic table for MongoDB results
  - JsonViewer: Syntax highlighted JSON view
  - HistorySidebar: List of previous queries
