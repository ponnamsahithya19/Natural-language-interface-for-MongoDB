import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion } from "framer-motion";

interface ResultTableProps {
  data: any[];
}

export function ResultTable({ data }: ResultTableProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-muted-foreground border border-dashed border-border rounded-xl bg-card/50">
        <p>No results found</p>
      </div>
    );
  }

  // Get all unique keys from all objects to form headers
  const headers = Array.from(
    new Set(data.flatMap((item) => Object.keys(item)))
  );

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden shadow-sm">
      <ScrollArea className="h-[500px] w-full">
        <Table>
          <TableHeader className="bg-muted/50 sticky top-0 z-10">
            <TableRow className="hover:bg-transparent border-border">
              {headers.map((header) => (
                <TableHead 
                  key={header} 
                  className="whitespace-nowrap font-mono text-xs uppercase tracking-wider text-muted-foreground h-10"
                >
                  {header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((row, i) => (
              <motion.tr
                key={i}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.2 }}
                className="border-b border-border hover:bg-muted/30 transition-colors"
              >
                {headers.map((header) => {
                  const val = row[header];
                  let displayVal = val;
                  
                  if (typeof val === 'object' && val !== null) {
                    displayVal = JSON.stringify(val);
                  } else if (typeof val === 'boolean') {
                    displayVal = val.toString();
                  }

                  return (
                    <TableCell key={`${i}-${header}`} className="font-mono text-xs py-3 max-w-[300px] truncate">
                      {displayVal}
                    </TableCell>
                  );
                })}
              </motion.tr>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
      <div className="bg-muted/30 p-2 text-xs text-muted-foreground border-t border-border flex justify-between px-4">
        <span>{data.length} documents</span>
        <span>ReadOnly View</span>
      </div>
    </div>
  );
}
