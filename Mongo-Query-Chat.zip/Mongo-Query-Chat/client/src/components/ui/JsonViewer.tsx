import { ScrollArea } from "@/components/ui/scroll-area";

interface JsonViewerProps {
  data: any;
  label?: string;
}

export function JsonViewer({ data, label }: JsonViewerProps) {
  return (
    <div className="rounded-xl border border-border bg-[#0d1117] overflow-hidden shadow-sm flex flex-col h-full">
      {label && (
        <div className="px-4 py-2 border-b border-border/50 bg-white/5 text-xs font-mono text-muted-foreground uppercase tracking-wider">
          {label}
        </div>
      )}
      <ScrollArea className="h-[500px] w-full">
        <pre className="p-4 text-xs font-mono leading-relaxed text-blue-100/90 overflow-x-auto">
          {JSON.stringify(data, null, 2)}
        </pre>
      </ScrollArea>
    </div>
  );
}
