import { useHistory } from "@/hooks/use-mongo-query";
import { formatDistanceToNow } from "date-fns";
import { Clock, Database, ChevronRight, Search } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

interface QueryHistoryProps {
  onSelectQuery: (question: string, collection: string) => void;
  className?: string;
}

export function QueryHistory({ onSelectQuery, className }: QueryHistoryProps) {
  const { data: history, isLoading } = useHistory();

  if (isLoading) {
    return (
      <div className={cn("flex flex-col gap-4 p-4", className)}>
        <Skeleton className="h-8 w-32 bg-muted/50" />
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-20 w-full rounded-xl bg-muted/30" />
        ))}
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col h-full", className)}>
      <div className="p-4 pb-2">
        <h3 className="font-display font-semibold text-sm text-foreground flex items-center gap-2">
          <Clock className="w-4 h-4 text-primary" />
          Recent Queries
        </h3>
      </div>
      
      <ScrollArea className="flex-1 px-4">
        <div className="flex flex-col gap-2 pb-4">
          {history?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              No query history yet.
            </div>
          ) : (
            history?.map((item) => (
              <button
                key={item.id}
                onClick={() => onSelectQuery(item.question, item.collection)}
                className="group flex flex-col gap-2 p-3 rounded-lg border border-border/50 bg-card hover:bg-muted/50 hover:border-primary/30 transition-all duration-200 text-left"
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Database className="w-3 h-3" />
                    {item.collection}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                  </span>
                </div>
                
                <p className="text-sm text-foreground/90 font-medium line-clamp-2 leading-snug">
                  "{item.question}"
                </p>
                
                <div className="flex items-center justify-between w-full pt-1 border-t border-border/30 mt-1">
                  <span className="text-[10px] text-muted-foreground font-mono truncate max-w-[180px]">
                    {item.mongoQuery}
                  </span>
                  <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                    {item.resultCount} results
                    <ChevronRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-primary" />
                  </span>
                </div>
              </button>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
