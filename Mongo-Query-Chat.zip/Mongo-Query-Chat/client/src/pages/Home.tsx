import { useState } from "react";
import { useCollections, useExecuteQuery } from "@/hooks/use-mongo-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResultTable } from "@/components/ui/ResultTable";
import { JsonViewer } from "@/components/ui/JsonViewer";
import { QueryHistory } from "@/components/QueryHistory";
import { 
  Sparkles, 
  Search, 
  Download, 
  Terminal, 
  Database,
  Loader2,
  Table as TableIcon,
  Code
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const { toast } = useToast();
  const [question, setQuestion] = useState("");
  const [collection, setCollection] = useState("");
  const [results, setResults] = useState<any>(null);
  const [mongoQuery, setMongoQuery] = useState<any>(null);
  
  const { data: collections, isLoading: isLoadingCollections } = useCollections();
  const { mutate: executeQuery, isPending: isExecuting } = useExecuteQuery();

  const handleSearch = () => {
    if (!question.trim()) {
      toast({
        title: "Query required",
        description: "Please enter a question to query your data.",
        variant: "destructive",
      });
      return;
    }
    if (!collection) {
      toast({
        title: "Collection required",
        description: "Please select a collection to query.",
        variant: "destructive",
      });
      return;
    }

    executeQuery(
      { question, collection },
      {
        onSuccess: (data) => {
          setResults(data.results);
          setMongoQuery(data.mongoQuery);
          toast({
            title: "Query successful",
            description: `Found ${data.results.length} documents.`,
          });
        },
        onError: (error) => {
          toast({
            title: "Query failed",
            description: error.message,
            variant: "destructive",
          });
        },
      }
    );
  };

  const handleDownloadCSV = () => {
    if (!results || results.length === 0) return;

    const headers = Array.from(new Set(results.flatMap((r: any) => Object.keys(r))));
    const csvContent = [
      headers.join(","),
      ...results.map((row: any) => 
        headers.map(header => {
          const val = row[header];
          return typeof val === 'object' ? `"${JSON.stringify(val).replace(/"/g, '""')}"` : `"${val}"`;
        }).join(",")
      )
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `export_${collection}_${new Date().toISOString()}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className="w-80 border-r border-border bg-muted/10 hidden lg:flex flex-col">
        <div className="p-6 border-b border-border/50">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center shadow-lg shadow-primary/20">
              <Database className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-lg tracking-tight">MongoAI</span>
          </div>
          <p className="text-xs text-muted-foreground ml-10">Natural Language Interface</p>
        </div>
        <QueryHistory 
          className="flex-1"
          onSelectQuery={(q, c) => {
            setQuestion(q);
            setCollection(c);
          }} 
        />
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Header / Query Input Section */}
        <div className="p-6 md:p-8 border-b border-border bg-background/95 backdrop-blur z-10">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="space-y-2">
              <h1 className="text-2xl md:text-3xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-white/70">
                Ask your data anything
              </h1>
              <p className="text-muted-foreground text-sm md:text-base max-w-xl">
                Select a collection and use natural language to query your MongoDB database. 
                AI generates the query for you.
              </p>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <div className="w-full md:w-64 flex-shrink-0">
                <Select value={collection} onValueChange={setCollection} disabled={isLoadingCollections}>
                  <SelectTrigger className="h-12 w-full bg-secondary/50 border-border/50 focus:ring-primary/20 hover:border-primary/50 transition-all rounded-xl">
                    <SelectValue placeholder={isLoadingCollections ? "Loading..." : "Select Collection"} />
                  </SelectTrigger>
                  <SelectContent>
                    {collections?.map((col) => (
                      <SelectItem key={col} value={col}>{col}</SelectItem>
                    ))}
                    {!isLoadingCollections && (!collections || collections.length === 0) && (
                      <SelectItem value="custom" disabled>No collections found</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1 relative group">
                <Input
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="e.g., Show me users who signed up last week and have active status..."
                  className="h-12 pl-4 pr-32 bg-secondary/50 border-border/50 focus:border-primary focus:ring-4 focus:ring-primary/10 rounded-xl transition-all shadow-sm"
                />
                <Button 
                  onClick={handleSearch}
                  disabled={isExecuting || !question || !collection}
                  className="absolute right-1 top-1 h-10 px-4 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg shadow-lg shadow-primary/20 transition-all hover:scale-105 active:scale-95 disabled:hover:scale-100 disabled:opacity-50"
                >
                  {isExecuting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Thinking...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Results Area */}
        <div className="flex-1 overflow-hidden p-6 md:p-8 bg-muted/5">
          <div className="max-w-7xl mx-auto h-full flex flex-col">
            <AnimatePresence mode="wait">
              {!results && !mongoQuery ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex flex-col items-center justify-center h-full text-center space-y-6 opacity-50"
                >
                  <div className="w-24 h-24 rounded-full bg-secondary/50 flex items-center justify-center mb-4">
                    <Search className="w-10 h-10 text-muted-foreground/50" />
                  </div>
                  <div className="space-y-2 max-w-md">
                    <h3 className="text-xl font-semibold text-foreground/80">Ready to Query</h3>
                    <p className="text-muted-foreground">
                      Select a collection and type your question above to see AI-generated MongoDB queries and results.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col h-full gap-6"
                >
                  {/* Generated Query Card */}
                  <div className="bg-card border border-border rounded-xl p-4 shadow-sm flex-shrink-0">
                    <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      <Terminal className="w-3 h-3 text-primary" />
                      Generated MongoDB Query
                    </div>
                    <code className="block font-mono text-sm text-blue-400 bg-black/30 p-3 rounded-lg overflow-x-auto">
                      db.{collection}.find({JSON.stringify(mongoQuery).replace(/^\{|\}$/g, '')})
                    </code>
                  </div>

                  {/* Results Tabs */}
                  <div className="flex-1 min-h-0 flex flex-col">
                    <Tabs defaultValue="table" className="h-full flex flex-col">
                      <div className="flex items-center justify-between mb-4">
                        <TabsList className="bg-secondary/50 p-1 rounded-lg border border-border/50">
                          <TabsTrigger value="table" className="data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md px-4 gap-2">
                            <TableIcon className="w-4 h-4" /> Table
                          </TabsTrigger>
                          <TabsTrigger value="json" className="data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md px-4 gap-2">
                            <Code className="w-4 h-4" /> JSON
                          </TabsTrigger>
                        </TabsList>

                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={handleDownloadCSV}
                          disabled={!results || results.length === 0}
                          className="gap-2 text-xs h-9"
                        >
                          <Download className="w-3.5 h-3.5" />
                          Export CSV
                        </Button>
                      </div>

                      <div className="flex-1 min-h-0 relative">
                        <TabsContent value="table" className="h-full mt-0 absolute inset-0">
                          <ResultTable data={results || []} />
                        </TabsContent>
                        <TabsContent value="json" className="h-full mt-0 absolute inset-0">
                          <JsonViewer data={results} />
                        </TabsContent>
                      </div>
                    </Tabs>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
}
