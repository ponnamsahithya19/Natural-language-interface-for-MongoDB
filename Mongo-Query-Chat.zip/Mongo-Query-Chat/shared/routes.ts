import { z } from 'zod';
import { queryHistory, insertQueryHistorySchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
    details: z.string().optional(),
  }),
};

export const api = {
  query: {
    execute: {
      method: 'POST' as const,
      path: '/api/query' as const,
      input: z.object({
        question: z.string(),
        collection: z.string(),
      }),
      responses: {
        200: z.object({
          question: z.string(),
          mongoQuery: z.any(),
          results: z.array(z.any()),
        }),
        400: errorSchemas.validation,
        500: errorSchemas.internal,
      },
    },
  },
  history: {
    list: {
      method: 'GET' as const,
      path: '/api/history' as const,
      responses: {
        200: z.array(z.custom<typeof queryHistory.$inferSelect>()),
      },
    },
  },
  collections: {
    list: {
      method: 'GET' as const,
      path: '/api/collections' as const,
      responses: {
        200: z.array(z.string()),
        500: errorSchemas.internal,
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type QueryExecuteInput = z.infer<typeof api.query.execute.input>;
export type QueryExecuteResponse = z.infer<typeof api.query.execute.responses[200]>;
export type HistoryListResponse = z.infer<typeof api.history.list.responses[200]>;
