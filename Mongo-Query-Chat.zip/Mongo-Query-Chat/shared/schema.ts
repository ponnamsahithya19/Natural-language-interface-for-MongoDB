import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const queryHistory = pgTable("query_history", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  collection: text("collection").notNull(),
  mongoQuery: text("mongo_query").notNull(), // Stringified JSON
  resultCount: integer("result_count").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertQueryHistorySchema = createInsertSchema(queryHistory).omit({ id: true, createdAt: true });

export type InsertQueryHistory = z.infer<typeof insertQueryHistorySchema>;
export type QueryHistory = typeof queryHistory.$inferSelect;
